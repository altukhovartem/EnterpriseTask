﻿using System;

namespace Incapsulation.EnterpriseTask
{
    class Transaction
    {
        public double Amount;
        public Guid EnterpriseGuid;
    }
}